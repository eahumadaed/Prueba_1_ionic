import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { FormsModule } from '@angular/forms';  // Importa FormsModule

import { CirculoComponent } from './components/circulo/circulo.component';
import { TrianguloEscalenoComponent } from './components/triangulo-escaleno/triangulo-escaleno.component';

@NgModule({
  declarations: [
    AppComponent,
    CirculoComponent,
    TrianguloEscalenoComponent
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    FormsModule  // Asegúrate de incluir FormsModule aquí
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
})
export class AppModule {}

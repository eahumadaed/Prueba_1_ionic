import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';  // Importación de HomePage

const routes: Routes = [
  {
    path: '',
    component: HomePage  // Componente HomePage en la ruta predeterminada
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomePageRoutingModule {}

import { FiguraGeometrica } from './figura-geometrica';  // Importa la clase base FiguraGeometrica

export class Circulo extends FiguraGeometrica {
  constructor(public radio: number) {
    super('Círculo');
  }

  calcularPerimetro(): number {
    return 2 * Math.PI * this.radio;  // Fórmula para calcular el perímetro de un círculo
  }
}

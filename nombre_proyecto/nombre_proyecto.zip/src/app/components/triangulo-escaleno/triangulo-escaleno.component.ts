import { Component } from '@angular/core';
import { TrianguloEscaleno } from '../../models/triangulo-escaleno';  // Importa la clase TrianguloEscaleno desde la carpeta models

@Component({
  selector: 'app-triangulo-escaleno',
  templateUrl: './triangulo-escaleno.component.html',
  styleUrls: ['./triangulo-escaleno.component.scss'],
})
export class TrianguloEscalenoComponent {
  ladoA: number = 0;  // Variable para almacenar el valor del primer lado
  ladoB: number = 0;  // Variable para almacenar el valor del segundo lado
  ladoC: number = 0;  // Variable para almacenar el valor del tercer lado
  perimetro: number | null = null;  // Variable para almacenar el resultado del perímetro calculado

  calcularPerimetro() {
    const triangulo = new TrianguloEscaleno(this.ladoA, this.ladoB, this.ladoC);  // Crea una instancia de la clase TrianguloEscaleno con los lados dados
    this.perimetro = triangulo.calcularPerimetro();  // Calcula el perímetro y lo almacena en la variable perimetro
  }
}

import { Component } from '@angular/core';
import { Circulo } from '../../models/circulo';  // Importa la clase Circulo desde la carpeta models

@Component({
  selector: 'app-circulo',
  templateUrl: './circulo.component.html',
  styleUrls: ['./circulo.component.scss'],
})
export class CirculoComponent {
  radio: number = 0;  // Variable para almacenar el valor del radio ingresado por el usuario
  perimetro: number | null = null;  // Variable para almacenar el resultado del perímetro calculado

  calcularPerimetro() {
    const circulo = new Circulo(this.radio);  // Crea una instancia de la clase Circulo con el radio dado
    this.perimetro = circulo.calcularPerimetro();  // Calcula el perímetro y lo almacena en la variable perimetro
  }
}
